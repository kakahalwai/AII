class Puzzle:
    def __init__(self, board):
        self.board = board
        self.size = 3

    def get_blank_position(self):
        for i in range(self.size):
            for j in range(self.size):
                if self.board[i][j] == 0:
                    return i, j

    def get_possible_moves(self):
        row, col = self.get_blank_position()
        moves = []
        if row > 0: moves.append("up")
        if row < self.size - 1: moves.append("down")
        if col > 0: moves.append("left")
        if col < self.size - 1: moves.append("right")
        return moves

    def move(self, direction):
        row, col = self.get_blank_position()
        new_board = [r[:] for r in self.board]
        dr, dc = {"up": (-1, 0), "down": (1, 0), "left": (0, -1), "right": (0, 1)}[direction]
        nr, nc = row + dr, col + dc
        new_board[row][col], new_board[nr][nc] = new_board[nr][nc], new_board[row][col]
        return Puzzle(new_board)

    def heuristic(self):
        goal = [[1,2,3],[4,5,6],[7,8,0]]
        return sum(
            1 for i in range(self.size) for j in range(self.size)
            if self.board[i][j] != 0 and self.board[i][j] != goal[i][j]
        )

    def __str__(self):
        return "\n".join(" ".join(f"{num:2}" for num in row) for row in self.board)

def hill_climbing(puzzle):
    current = puzzle
    while True:
        print("Current State:\n", current, "\nHeuristic:", current.heuristic(), "\n")
        neighbors = [current.move(move) for move in current.get_possible_moves()]
        best = min(neighbors, key=lambda x: x.heuristic(), default=current)
        if best.heuristic() < current.heuristic():
            current = best
        else:
            print("Reached Goal or Local Minimum")
            return current

def get_user_input():
    print("Enter the 3x3 puzzle board row by row (use 0 for the blank tile):")
    board = []
    for i in range(3):
        while True:
            try:
                row = list(map(int, input(f"Row {i+1}: ").split()))
                if len(row) == 3:
                    board.append(row)
                    break
                else:
                    print("❌ Each row must have exactly 3 numbers.")
            except ValueError:
                print("❌ Invalid input. Enter numbers only.")
    flat = [num for row in board for num in row]
    if sorted(flat) != list(range(9)):
        print("❌ Invalid board! Must contain numbers from 0 to 8 exactly once.")
        return get_user_input()
    return board

# Run the program
initial_board = get_user_input()
puzzle = Puzzle(initial_board)
final = hill_climbing(puzzle)
print("Final State:\n", final)


#1 2 3 
#4 0 6 
#7 5 8