import tkinter as tk
from tkinter import messagebox

def is_valid_position(row, col, queens):
    for r, c in queens:
        if r == row or c == col or abs(r - row) == abs(c - col):
            return False
    return True

def on_click(row, col):
    if buttons[row][col]["text"] == "" and is_valid_position(row, col, queens):
        buttons[row][col]["text"] = "Q"
        queens.append((row, col))
        if len(queens) == 4:
            if messagebox.askyesno("Success", "All 4 queens placed!\nPlay again?"):
                reset()
            else:
                root.destroy()
    else:
        messagebox.showwarning("Invalid", "Can't place queen here!")

def reset():
    for row in buttons:
        for btn in row:
            btn.config(text="")
    queens.clear()

# Setup window
root = tk.Tk()
root.title("4-Queen Game")

buttons = []
queens = []

# Create 4x4 board
for i in range(4):
    row_buttons = []
    for j in range(4):
        btn = tk.Button(root, text="", font=("Arial", 18), width=5, height=2,
                        command=lambda r=i, c=j: on_click(r, c))
        btn.grid(row=i, column=j)
        row_buttons.append(btn)
    buttons.append(row_buttons)

root.mainloop()
