def print_grid(grid):
    for row in grid:
        print(" | ".join(str(x).rjust(2) if x != 0 else "  " for x in row))
    print()

def is_magic_square(grid):
    # Flatten and check if numbers 1-9 are used
    nums = [n for row in grid for n in row]
    if sorted(nums) != list(range(1, 10)):
        return False

    s = sum(grid[0])  # target sum
    rows = all(sum(row) == s for row in grid)
    cols = all(sum(grid[i][j] for i in range(3)) == s for j in range(3))
    diag1 = sum(grid[i][i] for i in range(3)) == s
    diag2 = sum(grid[i][2 - i] for i in range(3)) == s

    return rows and cols and diag1 and diag2

def main():
    grid = [[0] * 3 for _ in range(3)]
    used = set()

    print("🧙 Magic Square Game (3x3) — Use numbers 1 to 9 once to fill the grid.")
    print("Enter row, column, and value (e.g., 0 1 5 means row 0, column 1, value 5).")
    print_grid(grid)

    while len(used) < 9:
        try:
            inp = input("Enter row col num: ").split()
            if len(inp) != 3:
                print("❌ Enter exactly 3 numbers.")
                continue
            r, c, n = map(int, inp)
            if not (0 <= r <= 2 and 0 <= c <= 2 and 1 <= n <= 9):
                print("❌ Row/Col must be 0–2 and number 1–9.")
                continue
            if grid[r][c] != 0:
                print("❌ Cell already filled.")
                continue
            if n in used:
                print("❌ Number already used.")
                continue
            grid[r][c] = n
            used.add(n)
            print_grid(grid)
        except:
            print("❌ Invalid input. Try again.")

    if is_magic_square(grid):
        print("🎉 Congrats! It's a Magic Square!")
    else:
        print("😔 Not a Magic Square. Try again!")

if __name__ == "__main__":
    main()
