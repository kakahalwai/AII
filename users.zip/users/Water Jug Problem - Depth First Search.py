def water_jug_dfs(cap_x, cap_y, target, target_jug):
    start = (0, 0)
    stack = [start]
    visited = set()
    path = []

    while stack:
        x, y = stack.pop()

        if (x, y) in visited:
            continue
        visited.add((x, y))
        path.append((x, y))

        if (target_jug == 'A' and x == target) or (target_jug == 'B' and y == target):
            print("\n✅ Solution Path:")
            for a, b in path:
                print(f"A={a}, B={b}")
            return True

        # Possible next moves
        next_states = [
            (cap_x, y),        # Fill A
            (x, cap_y),        # Fill B
            (0, y),            # Empty A
            (x, 0),            # Empty B
            (x - min(x, cap_y - y), y + min(x, cap_y - y)),  # A → B
            (x + min(y, cap_x - x), y - min(y, cap_x - x)),  # B → A
        ]

        stack.extend(next_states)

    print("\n❌ No solution found.")
    return False


# --- User Input ---
print("Water Jug Problem using DFS")

cap_x = int(input("Capacity of Jug A: "))
cap_y = int(input("Capacity of Jug B: "))
target_jug = input("Target Jug (A or B): ").strip().upper()
while target_jug not in ['A', 'B']:
    target_jug = input("Please enter 'A' or 'B': ").strip().upper()

target = int(input(f"Target amount in Jug {target_jug}: "))
if (target_jug == 'A' and target > cap_x) or (target_jug == 'B' and target > cap_y):
    print("❌ Target cannot exceed jug capacity.")
else:
    water_jug_dfs(cap_x, cap_y, target, target_jug)