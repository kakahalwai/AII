import heapq, math
from typing import List, Tuple, Optional

class RobotNavigation:
    DIRECTIONS = [(-1,0),(1,0),(0,-1),(0,1)]
    def __init__(self, grid: List[List[int]]):
        self.grid = grid
        self.rows = len(grid)
        self.cols = len(grid[0]) if grid else 0
    def is_valid(self, r: int, c: int) -> bool:
        return 0 <= r < self.rows and 0 <= c < self.cols and self.grid[r][c] == 0
    def heuristic(self, a: Tuple[int, int], b: Tuple[int, int]) -> float:
        return math.hypot(a[0]-b[0], a[1]-b[1])
    def get_neighbors(self, p: Tuple[int, int]):
        r,c = p
        return [(r+dr, c+dc) for dr,dc in self.DIRECTIONS if self.is_valid(r+dr, c+dc)]
    def best_first_search(self, start: Tuple[int, int], goal: Tuple[int, int]) -> Optional[List[Tuple[int, int]]]:
        if not self.is_valid(*start) or not self.is_valid(*goal): return None
        open_set = [(self.heuristic(start, goal), start)]
        came_from = {start: None}
        visited = set()
        while open_set:
            _, cur = heapq.heappop(open_set)
            if cur == goal:
                path = []
                while cur: path.append(cur); cur = came_from[cur]
                return path[::-1]
            visited.add(cur)
            for n in self.get_neighbors(cur):
                if n not in visited and n not in came_from:
                    came_from[n] = cur
                    heapq.heappush(open_set, (self.heuristic(n, goal), n))
        return None

def visualize_path(grid: List[List[int]], path: List[Tuple[int, int]]):
    for r in range(len(grid)):
        for c in range(len(grid[0])):
            print("P" if (r,c) in path else "#" if grid[r][c] else ".", end=" ")
        print()

if __name__=="__main__":
    grid = [
        [0,0,0,0,1,0,0,0,0,0],
        [0,0,0,0,1,0,0,0,0,0],
        [0,0,0,0,1,0,0,0,0,0],
        [0,0,0,0,1,0,0,0,0,0],
        [0,0,0,0,1,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0,0],
        [0,0,0,0,1,0,0,0,0,0],
        [0,0,0,0,1,0,0,0,0,0],
        [0,0,0,0,1,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0,0]
    ]
    start, goal = (0,0), (9,9)
    nav = RobotNavigation(grid)
    path = nav.best_first_search(start, goal)
    if path:
        print("Path found:\n", path, "\n\nVisualization:")
        visualize_path(grid, path)
    else: print("No path found.")
