import heapq
class PuzzleState:
  def __init__(self, board, parent=None, move=None):
    self.board = board
    self.parent = parent
    self.move = move
    self.heuristic = self.calculate_manhattan_distance()
    self.priority = self.heuristic

  def __lt__(self, other):
    return self.priority < other.priority

  def calculate_manhattan_distance(self):
    goal_state = {1: (0, 0), 2: (0, 1), 3: (0, 2),
           4: (1, 0), 5: (1, 1), 6: (1, 2),
           7: (2, 0), 8: (2, 1), 0: (2, 2)}
    distance = 0
    for i in range(3):
      for j in range(3):
        tile = self.board[i][j]
        if tile != 0:
          x, y = goal_state[tile]
          distance += abs(x - i) + abs(y - j)
    return distance

  def get_neighbors(self):
    neighbors = []
    moves = {'UP': (-1, 0), 'DOWN': (1, 0), 'LEFT': (0, -1), 'RIGHT': (0, 1)}
    x, y = [(r, c) for r in range(3) for c in range(3) if self.board[r][c] == 0][0]

    for move, (dx, dy) in moves.items():
      nx, ny = x + dx, y + dy
      if 0 <= nx < 3 and 0 <= ny < 3:
        new_board = [row[:] for row in self.board]
        new_board[x][y], new_board[nx][ny] = new_board[nx][ny], new_board[x][y]
        neighbors.append(PuzzleState(new_board, self, move))
    
    return neighbors

  def get_path(self):
    path, state = [], self
    while state:
      if state.move:
        path.append((state.move, state.board))
      state = state.parent
    return path[::-1]

def print_board(board):
  for row in board:
    print(" ".join(str(tile) if tile != 0 else " " for tile in row))
  print("\n" + "-"*10 + "\n")

def best_first_search_8_puzzle(start):
  pq = []
  heapq.heappush(pq, start)
  visited = set()

  while pq:
    state = heapq.heappop(pq)
    if state.heuristic == 0:
      return state.get_path()
    
    visited.add(tuple(map(tuple, state.board)))
    
    for neighbor in state.get_neighbors():
      if tuple(map(tuple, neighbor.board)) not in visited:
        heapq.heappush(pq, neighbor)
  
  return None
# User Input
print("Enter 8-puzzle board row by row (use 0 for empty tile):")
start_board = [list(map(int, input().split())) for _ in range(3)]

initial_state = PuzzleState(start_board)
solution = best_first_search_8_puzzle(initial_state)

if solution:
  print("\nStep-by-step solution:")
  print_board(start_board) # Print initial state
  for move, board in solution:
    print(f"Move: {move}")
    print_board(board)
else:
  print("No solution found!")
#3 1 2
#6 7 8
#4 5 0