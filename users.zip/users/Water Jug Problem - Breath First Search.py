from collections import deque

def water_jug_bfs(cap_x, cap_y, target, target_jug):
    start = (0, 0)
    queue = deque([start])
    visited = set()
    parent = {}

    while queue:
        x, y = queue.popleft()

        if (target_jug == 'A' and x == target) or (target_jug == 'B' and y == target):
            # Reconstruct and print path
            path = []
            while (x, y) != start:
                path.append((x, y))
                x, y = parent[(x, y)]
            path.append(start)
            path.reverse()

            print("\n✅ Solution Path (BFS):")
            for a, b in path:
                print(f"A={a}, B={b}")
            return True

        if (x, y) in visited:
            continue
        visited.add((x, y))

        next_states = [
            (cap_x, y),        # Fill A
            (x, cap_y),        # Fill B
            (0, y),            # Empty A
            (x, 0),            # Empty B
            (x - min(x, cap_y - y), y + min(x, cap_y - y)),  # A → B
            (x + min(y, cap_x - x), y - min(y, cap_x - x)),  # B → A
        ]

        for state in next_states:
            if state not in visited:
                parent[state] = (x, y)
                queue.append(state)

    print("\n❌ No solution found.")
    return False

# --- User Input ---
print("Water Jug Problem using BFS")

cap_x = int(input("Capacity of Jug A: "))
cap_y = int(input("Capacity of Jug B: "))

target_jug = input("Target Jug (A or B): ").strip().upper()
while target_jug not in ['A', 'B']:
    target_jug = input("Please enter 'A' or 'B': ").strip().upper()

target = int(input(f"Target amount in Jug {target_jug}: "))
if (target_jug == 'A' and target > cap_x) or (target_jug == 'B' and target > cap_y):
    print("❌ Target exceeds capacity.")
else:
    water_jug_bfs(cap_x, cap_y, target, target_jug)
