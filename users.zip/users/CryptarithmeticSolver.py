class SimpleCryptarithmeticSolver:
    def __init__(self, puzzle):
        """
        Initialize with a puzzle string like "SEND + MORE = MONEY"
        """
        # Parse the puzzle into addends and result
        equation = puzzle.replace(" ", "").split("=")
        self.result = equation[1].strip()
        self.addends = [word.strip() for word in equation[0].split("+")]
        
        # Collect all unique letters
        all_words = self.addends + [self.result]
        self.letters = set(letter for word in all_words for letter in word)
        
        # Find letters that start words (these can't be zero)
        self.first_letters = {word[0] for word in all_words}
        
        # Convert sets to lists for easier iteration
        self.letters = list(self.letters)
        self.solution = {}
    
    def solve(self):
        """Find a valid digit assignment for all letters"""
        # Begin recursive search with all digits available
        return self._try_assignments(0, list(range(10)))
    
    def _try_assignments(self, letter_index, available_digits):
        """Try assigning digits to letters recursively"""
        # If all letters have been assigned, check if solution is valid
        if letter_index >= len(self.letters):
            return self._check_solution()
        
        current_letter = self.letters[letter_index]
        
        # Try each available digit for the current letter
        for i, digit in enumerate(available_digits):
            # Skip assigning zero to first letters
            if digit == 0 and current_letter in self.first_letters:
                continue
                
            # Try this digit for the current letter
            self.solution[current_letter] = digit
            
            # Remove this digit from available ones
            remaining_digits = available_digits.copy()
            remaining_digits.pop(i)
            
            # Recursively try to assign digits to remaining letters
            if self._try_assignments(letter_index + 1, remaining_digits):
                return True
        
        # If we get here, no valid assignment was found
        if current_letter in self.solution:
            del self.solution[current_letter]
        return False
    
    def _check_solution(self):
        """Check if current assignment satisfies the equation"""
        # Convert words to numbers using the current assignment
        values = {}
        
        for word in self.addends + [self.result]:
            value = 0
            for letter in word:
                value = value * 10 + self.solution[letter]
            values[word] = value
        
        # Check if sum of addends equals result
        sum_of_addends = sum(values[addend] for addend in self.addends)
        return sum_of_addends == values[self.result]
    
    def get_solution(self):
        """Return a formatted solution string"""
        if not self.solution:
            return "No solution found"
        
        # Create a dictionary of letter-to-digit mappings
        letter_map = {l: self.solution[l] for l in self.letters}
        
        # Convert words to their numeric values
        word_values = {}
        for word in self.addends + [self.result]:
            value = 0
            for letter in word:
                value = value * 10 + self.solution[letter]
            word_values[word] = value
        
        # Format the result
        result = ["Solution:"]
        result.append(f"Letter mapping: {letter_map}")
        
        # Show the equation with values
        equation_parts = []
        for addend in self.addends:
            equation_parts.append(f"{addend} = {word_values[addend]}")
        
        equation = " + ".join(equation_parts)
        equation += f" = {self.result} = {word_values[self.result]}"
        
        result.append(equation)
        return "\n".join(result)


# Example usage
if __name__ == "__main__":
    puzzle = "SEND + MORE = MONEY"
    solver = SimpleCryptarithmeticSolver(puzzle)
    if solver.solve():
        print(solver.get_solution())
    else:
        print("No solution found")